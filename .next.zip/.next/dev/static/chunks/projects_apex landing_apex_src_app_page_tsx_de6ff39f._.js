(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/projects_apex landing_apex_src_app_a83e9b66._.js",
  "static/chunks/5f7a6_1ae0e7bd._.js",
  "static/chunks/projects_apex landing_apex_src_app_core_ac163fbb._.css"
],
    source: "dynamic"
});
