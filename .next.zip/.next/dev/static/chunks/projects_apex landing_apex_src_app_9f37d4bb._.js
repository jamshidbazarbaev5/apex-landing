(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TransportServices
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
;
;
function TransportServices() {
    const services = [
        {
            id: 1,
            title: "Full Truckload (FTL)",
            description: "Direct delivery with a dedicated truck and driver, ideal for large shipments.",
            image: "https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?w=800&q=80"
        },
        {
            id: 2,
            title: "Medical Equipment",
            description: "Time-critical and temperature-controlled deliveries for healthcare and hospitals.",
            image: "https://images.unsplash.com/photo-1631815588090-d4bfec5b1ccb?w=800&q=80"
        },
        {
            id: 3,
            title: "Local Courier Deliveries",
            description: "Same-day solutions for documents and small parcels.",
            image: "https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?w=800&q=80"
        },
        {
            id: 4,
            title: "Less-Than-Truckload (LTL)",
            description: "Reliable and cost-efficient transport for smaller shipments.",
            image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800&q=80"
        },
        {
            id: 5,
            title: "Casino & Gaming Equipment",
            description: "Secure, high-value freight handling with dedicated tracking.",
            image: "https://images.unsplash.com/photo-1596838132731-3301c3fd4317?w=800&q=80"
        },
        {
            id: 6,
            title: "Door-to-Door Delivery",
            description: "Convenient and reliable pickup and drop-off service anywhere in the U.S. and Canada.",
            image: "https://images.unsplash.com/photo-1605902711622-cfb43c4437f5?w=800&q=80"
        },
        {
            id: 7,
            title: "Cross-Border Shipping",
            description: "Seamless movement between the U.S. and Canada with customs support.",
            image: "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=800&q=80"
        },
        {
            id: 8,
            title: "Trade Shows & Events",
            description: "On-time setup and breakdown deliveries for exhibitions and conventions.",
            image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&q=80"
        },
        {
            id: 9,
            title: "White Glove Service",
            description: "Premium handling for fragile, high-value, or specialized freight.",
            image: "https://images.unsplash.com/photo-1607400201889-565b1ee75f8e?w=800&q=80"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "e514760edec705be",
                children: ".services-section.jsx-e514760edec705be{background-color:#e8e6e1;padding:80px 40px}.services-container.jsx-e514760edec705be{max-width:1400px;margin:0 auto}.services-header.jsx-e514760edec705be{text-align:center;margin-bottom:60px}.services-title.jsx-e514760edec705be{color:#3d4f5f;margin-bottom:16px;font-size:42px;font-weight:700;line-height:1.3}.services-subtitle.jsx-e514760edec705be{color:#5f6d7a;font-size:18px;line-height:1.6}.services-grid.jsx-e514760edec705be{grid-template-columns:repeat(3,1fr);gap:30px;display:grid}.service-card.jsx-e514760edec705be{cursor:pointer;border-radius:24px;height:280px;transition:transform .3s,box-shadow .3s;position:relative;overflow:hidden}.service-card.jsx-e514760edec705be:hover{transform:translateY(-8px);box-shadow:0 12px 40px #00000026}.service-image.jsx-e514760edec705be{object-fit:cover;width:100%;height:100%}.service-overlay.jsx-e514760edec705be{text-align:center;background:linear-gradient(#0003 0%,#0009 100%);flex-direction:column;justify-content:center;align-items:center;padding:30px;display:flex;position:absolute;inset:0}.service-card-title.jsx-e514760edec705be{color:#fff;text-shadow:0 2px 8px #0000004d;margin-bottom:12px;font-size:24px;font-weight:700}.service-card-description.jsx-e514760edec705be{color:#fff;text-shadow:0 1px 4px #0000004d;font-size:15px;line-height:1.5}@media (width<=1024px){.services-grid.jsx-e514760edec705be{grid-template-columns:repeat(2,1fr)}}@media (width<=640px){.services-section.jsx-e514760edec705be{padding:60px 20px}.services-title.jsx-e514760edec705be{font-size:32px}.services-subtitle.jsx-e514760edec705be{font-size:16px}.services-grid.jsx-e514760edec705be{grid-template-columns:1fr;gap:20px}.service-card.jsx-e514760edec705be{height:240px}.service-card-title.jsx-e514760edec705be{font-size:20px}.service-card-description.jsx-e514760edec705be{font-size:14px}}"
            }, void 0, false, void 0, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "jsx-e514760edec705be" + " " + "services-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "jsx-e514760edec705be" + " " + "services-container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-e514760edec705be" + " " + "services-header",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "jsx-e514760edec705be" + " " + "services-title",
                                    children: "Transport Solutions That Work for You"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                    lineNumber: 192,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "jsx-e514760edec705be" + " " + "services-subtitle",
                                    children: "No matter the load — we deliver safely, on time, and with full visibility."
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                    lineNumber: 195,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                            lineNumber: 191,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-e514760edec705be" + " " + "services-grid",
                            children: services.map((service)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-e514760edec705be" + " " + "service-card",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: service.image,
                                            alt: service.title,
                                            className: "jsx-e514760edec705be" + " " + "service-image"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                            lineNumber: 203,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "jsx-e514760edec705be" + " " + "service-overlay",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "jsx-e514760edec705be" + " " + "service-card-title",
                                                    children: service.title
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                                    lineNumber: 209,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "jsx-e514760edec705be" + " " + "service-card-description",
                                                    children: service.description
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                                    lineNumber: 210,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                            lineNumber: 208,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, service.id, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                    lineNumber: 202,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                            lineNumber: 200,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                    lineNumber: 190,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                lineNumber: 189,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c = TransportServices;
var _c;
__turbopack_context__.k.register(_c, "TransportServices");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FleetEquipment
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
;
;
function FleetEquipment() {
    const vehicles = [
        {
            id: 1,
            name: "Cargo Van",
            image: '/cargovan.png',
            features: [
                "Single covered van",
                "100% insured",
                "Direct & ASAP delivery"
            ]
        },
        {
            id: 2,
            name: "Sprinter Van",
            image: '/cargovan.png',
            features: [
                "More cargo space",
                "GPS-tracked",
                "Ideal for expedited small loads"
            ]
        },
        {
            id: 3,
            name: "Small Straight",
            image: '/cargovan.png',
            features: [
                "Liftgate optional",
                "Perfect for local LTL and residential deliveries",
                "100% insurance"
            ]
        },
        {
            id: 4,
            name: "Straight Truck",
            image: '/cargovan.png',
            features: [
                "Pallet jack & liftgate",
                "Expedited and regional deliveries",
                "Ideal for medical, trade show, or industrial freight"
            ]
        },
        {
            id: 5,
            name: "Semi Truck",
            image: '/cargovan.png',
            features: [
                "Nationwide coverage",
                "Team drivers available",
                "Perfect for large volume and long-haul freight"
            ]
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "5c0a9aadd3a0edf8",
                children: '.fleet-section.jsx-5c0a9aadd3a0edf8{background-color:#e8e6e1;padding:80px 40px}.fleet-container.jsx-5c0a9aadd3a0edf8{max-width:1400px;margin:0 auto}.fleet-header.jsx-5c0a9aadd3a0edf8{text-align:center;margin-bottom:60px}.fleet-title.jsx-5c0a9aadd3a0edf8{color:#3d4f5f;margin-bottom:16px;font-size:42px;font-weight:700;line-height:1.3}.fleet-subtitle.jsx-5c0a9aadd3a0edf8{color:#5f6d7a;font-size:18px;line-height:1.6}.fleet-grid.jsx-5c0a9aadd3a0edf8{grid-template-columns:repeat(5,1fr);gap:24px;margin-bottom:40px;display:grid}.vehicle-card.jsx-5c0a9aadd3a0edf8{background:#fff;border-radius:20px;flex-direction:column;align-items:center;padding:30px 24px;transition:transform .3s,box-shadow .3s;display:flex;box-shadow:0 2px 8px #00000014}.vehicle-card.jsx-5c0a9aadd3a0edf8:hover{transform:translateY(-8px);box-shadow:0 8px 24px #0000001f}.vehicle-name.jsx-5c0a9aadd3a0edf8{color:#3d4f5f;text-align:center;margin-bottom:24px;font-size:22px;font-weight:700}.vehicle-image-container.jsx-5c0a9aadd3a0edf8{justify-content:center;align-items:center;width:100%;height:180px;margin-bottom:32px;display:flex}.vehicle-image.jsx-5c0a9aadd3a0edf8{object-fit:contain;width:100%;height:100%}.vehicle-features.jsx-5c0a9aadd3a0edf8{width:100%;margin:0;padding:0;list-style:none}.vehicle-feature.jsx-5c0a9aadd3a0edf8{color:#6b7280;margin-bottom:12px;padding-left:12px;font-size:15px;line-height:1.6;position:relative}.vehicle-feature.jsx-5c0a9aadd3a0edf8:before{content:"–";color:#9ca3af;position:absolute;left:0}.vehicle-feature.jsx-5c0a9aadd3a0edf8:last-child{margin-bottom:0}@media (width<=1280px){.fleet-grid.jsx-5c0a9aadd3a0edf8{grid-template-columns:repeat(3,1fr)}}@media (width<=768px){.fleet-section.jsx-5c0a9aadd3a0edf8{padding:60px 20px}.fleet-title.jsx-5c0a9aadd3a0edf8{font-size:32px}.fleet-subtitle.jsx-5c0a9aadd3a0edf8{font-size:16px}.fleet-grid.jsx-5c0a9aadd3a0edf8{grid-template-columns:repeat(2,1fr);gap:16px}.vehicle-card.jsx-5c0a9aadd3a0edf8{padding:24px 16px}.vehicle-name.jsx-5c0a9aadd3a0edf8{font-size:18px}.vehicle-image-container.jsx-5c0a9aadd3a0edf8{height:140px;margin-bottom:20px}.vehicle-feature.jsx-5c0a9aadd3a0edf8{font-size:14px}}@media (width<=480px){.fleet-grid.jsx-5c0a9aadd3a0edf8{grid-template-columns:1fr}}'
            }, void 0, false, void 0, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "jsx-5c0a9aadd3a0edf8" + " " + "fleet-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "jsx-5c0a9aadd3a0edf8" + " " + "fleet-container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-5c0a9aadd3a0edf8" + " " + "fleet-header",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "jsx-5c0a9aadd3a0edf8" + " " + "fleet-title",
                                    children: "Fleet & Equipment Options"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                    lineNumber: 212,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "jsx-5c0a9aadd3a0edf8" + " " + "fleet-subtitle",
                                    children: "The right equipment for every type of freight — from local courier runs to cross-country shipments"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                    lineNumber: 215,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                            lineNumber: 211,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-5c0a9aadd3a0edf8" + " " + "fleet-grid",
                            children: vehicles.map((vehicle)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-5c0a9aadd3a0edf8" + " " + "vehicle-card",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "jsx-5c0a9aadd3a0edf8" + " " + "vehicle-name",
                                            children: vehicle.name
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                            lineNumber: 223,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "jsx-5c0a9aadd3a0edf8" + " " + "vehicle-image-container",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: vehicle.image,
                                                alt: vehicle.name,
                                                className: "jsx-5c0a9aadd3a0edf8" + " " + "vehicle-image"
                                            }, void 0, false, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                                lineNumber: 225,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                            lineNumber: 224,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "jsx-5c0a9aadd3a0edf8" + " " + "vehicle-features",
                                            children: vehicle.features.map((feature, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "jsx-5c0a9aadd3a0edf8" + " " + "vehicle-feature",
                                                    children: feature
                                                }, index, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                                    lineNumber: 233,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                            lineNumber: 231,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, vehicle.id, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                    lineNumber: 222,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                            lineNumber: 220,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                    lineNumber: 210,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                lineNumber: 209,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c = FleetEquipment;
var _c;
__turbopack_context__.k.register(_c, "FleetEquipment");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>About
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/image.js [app-client] (ecmascript)");
;
;
;
function About() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "jsx-5235707e1d483929" + " " + "about-section",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-5235707e1d483929" + " " + "about-container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "jsx-5235707e1d483929" + " " + "about-title",
                        children: "About Axper"
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                        lineNumber: 6,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-5235707e1d483929" + " " + "about-content",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-5235707e1d483929" + " " + "about-text",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-5235707e1d483929",
                                        children: "At Axper, we specialize in dependable, efficient, and flexible logistics solutions across the U.S. and Canada"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 10,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-5235707e1d483929",
                                        children: "Whether it's a single box or a full truckload, our experienced team ensures every shipment arrives safely and on time."
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 12,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-5235707e1d483929",
                                        children: "With years of experience, a trusted carrier network, and dedicated dispatch professionals, we help businesses streamline their supply chains with reliability and transparency."
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 14,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-5235707e1d483929",
                                        children: "Let us handle the logistics — so you can focus on growing your business."
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 16,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                lineNumber: 9,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-5235707e1d483929" + " " + "about-branding",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-5235707e1d483929" + " " + "axper-logo",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: "/mainlogo.png",
                                        width: 500,
                                        height: 500,
                                        alt: "logo"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 21,
                                        columnNumber: 14
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                    lineNumber: 20,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                lineNumber: 19,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                        lineNumber: 8,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                lineNumber: 5,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "5235707e1d483929",
                children: ".about-section.jsx-5235707e1d483929{background-color:#f5f5f5;justify-content:center;align-items:center;min-height:100vh;padding:80px 40px;display:flex}.about-container.jsx-5235707e1d483929{width:100%;max-width:1200px;margin:0 auto}.about-title.jsx-5235707e1d483929{text-align:center;color:#2d3e50;letter-spacing:-.5px;margin-bottom:80px;font-size:32px;font-weight:600}.about-content.jsx-5235707e1d483929{align-items:center;gap:100px;display:flex}.about-text.jsx-5235707e1d483929{flex-direction:column;flex:1;gap:24px;display:flex}.about-text.jsx-5235707e1d483929 p.jsx-5235707e1d483929{color:#666;margin:0;font-family:Geist,sans-serif;font-size:16px;line-height:1.6}.about-branding.jsx-5235707e1d483929{flex-direction:column;flex:1;justify-content:center;align-items:center;gap:20px;display:flex}.axper-logo.jsx-5235707e1d483929{justify-content:center;align-items:center;width:500px;height:500px;display:flex}.axper-logo.jsx-5235707e1d483929 svg.jsx-5235707e1d483929{width:100%;height:100%}.axper-name.jsx-5235707e1d483929{color:#2d3e50;letter-spacing:-1px;margin:20px 0 0;font-size:48px;font-weight:700}.axper-tagline.jsx-5235707e1d483929{color:#999;letter-spacing:1px;text-transform:lowercase;margin:0;font-family:Geist,sans-serif;font-size:14px}@media (width<=768px){.about-section.jsx-5235707e1d483929{padding:60px 30px}.about-content.jsx-5235707e1d483929{flex-direction:column;gap:60px}.about-title.jsx-5235707e1d483929{margin-bottom:60px;font-size:28px}.about-text.jsx-5235707e1d483929{gap:20px}.about-text.jsx-5235707e1d483929 p.jsx-5235707e1d483929{font-size:15px}.axper-name.jsx-5235707e1d483929{font-size:40px}}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
        lineNumber: 4,
        columnNumber: 5
    }, this);
}
_c = About;
var _c;
__turbopack_context__.k.register(_c, "About");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Contact
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../styles/'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function Contact() {
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        phone: '',
        email: '',
        message: ''
    });
    const handleChange = (e)=>{
        const { name, value } = e.target;
        setFormData((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const handleSubmit = (e)=>{
        e.preventDefault();
        console.log('Form submitted:', formData);
        // Add your form submission logic here
        setFormData({
            name: '',
            phone: '',
            email: '',
            message: ''
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: styles.contactSection,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: styles.container,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: styles.heading,
                    children: "Contact Us"
                }, void 0, false, {
                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: styles.content,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: styles.leftColumn,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: styles.tagline,
                                    children: "Let's Move Freight Together"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                    lineNumber: 36,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: styles.description,
                                    children: [
                                        "Have a question or need a quote? We're always ready to help",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 38,
                                            columnNumber: 74
                                        }, this),
                                        "Call, email, or fill out the form — our team responds within 15 minutes during business hours."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                    lineNumber: 37,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: styles.contactInfo,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: styles.infoItem,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: styles.label,
                                                    children: "Company Phone"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 44,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "tel:(940) 398-0770",
                                                    className: styles.link,
                                                    children: "(940) 398-0770"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 45,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 43,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: styles.infoItem,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: styles.label,
                                                    children: "24/7 Operations Phone"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 49,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "tel:(940) 398-0110",
                                                    className: styles.link,
                                                    children: "(940) 398-0110"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 50,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 48,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: styles.infoItem,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: styles.label,
                                                    children: "24/7 Email"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 54,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "mailto:ops@axpergroup.com",
                                                    className: styles.link,
                                                    children: "ops@axpergroup.com"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 55,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 53,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: styles.infoItem,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: styles.label,
                                                    children: "Address"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 59,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: styles.text,
                                                    children: "1673 Reed Dr, Krum, TX, 76249, US"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 60,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 58,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: styles.infoItem,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: styles.label,
                                                    children: "MC"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 64,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: styles.text,
                                                    children: "1603523"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 65,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 63,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: styles.infoItem,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: styles.label,
                                                    children: "USDOT"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 69,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: styles.text,
                                                    children: "4169562"
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                    lineNumber: 70,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 68,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                    lineNumber: 42,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                            lineNumber: 35,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            className: styles.form,
                            onSubmit: handleSubmit,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: styles.formGroup,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        name: "name",
                                        placeholder: "Name",
                                        value: formData.name,
                                        onChange: handleChange,
                                        className: styles.input,
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 77,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                    lineNumber: 76,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: styles.formGroup,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "tel",
                                        name: "phone",
                                        placeholder: "Phone",
                                        value: formData.phone,
                                        onChange: handleChange,
                                        className: styles.input,
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 89,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                    lineNumber: 88,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: styles.formGroup,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "email",
                                        name: "email",
                                        placeholder: "Email",
                                        value: formData.email,
                                        onChange: handleChange,
                                        className: styles.input,
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 101,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                    lineNumber: 100,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: styles.formGroup,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                        name: "message",
                                        placeholder: "Message",
                                        value: formData.message,
                                        onChange: handleChange,
                                        className: styles.textarea,
                                        required: true
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 113,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                    lineNumber: 112,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "submit",
                                    className: styles.submitBtn,
                                    children: "Submit"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                    lineNumber: 123,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                            lineNumber: 75,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
            lineNumber: 31,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_s(Contact, "ejAbss8tiQyHDCSZpBxZDKd78t8=");
_c = Contact;
var _c;
__turbopack_context__.k.register(_c, "Contact");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$FleetEqupment$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$About$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Contact$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
function HeroSection() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-[#e8e6e1] flex flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "px-8 py-6 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-10 h-10 relative",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    viewBox: "0 0 40 40",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "8",
                                            cy: "8",
                                            r: "3",
                                            fill: "#2d3748"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 15,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "32",
                                            cy: "8",
                                            r: "3",
                                            fill: "#2d3748"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 16,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "20",
                                            cy: "32",
                                            r: "3",
                                            fill: "#2d3748"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 17,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "8",
                                            y1: "8",
                                            x2: "20",
                                            y2: "32",
                                            stroke: "#2d3748",
                                            strokeWidth: "2"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 18,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "32",
                                            y1: "8",
                                            x2: "20",
                                            y2: "32",
                                            stroke: "#2d3748",
                                            strokeWidth: "2"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 19,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "8",
                                            y1: "8",
                                            x2: "32",
                                            y2: "8",
                                            stroke: "#2d3748",
                                            strokeWidth: "2"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 20,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                    lineNumber: 14,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 13,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-2xl font-semibold text-gray-800",
                                children: "Axper"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 23,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                        lineNumber: 12,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "flex gap-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                className: "text-gray-700 hover:text-gray-900 font-medium",
                                children: "HOME"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 27,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                className: "text-gray-700 hover:text-gray-900 font-medium",
                                children: "SERVICES"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 28,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                className: "text-gray-700 hover:text-gray-900 font-medium",
                                children: "ABOUT US"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 29,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                className: "text-gray-700 hover:text-gray-900 font-medium",
                                children: "APPLICATION"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 30,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                className: "text-gray-700 hover:text-gray-900 font-medium",
                                children: "CONTACT US"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 31,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "flex-1 flex items-center justify-center px-8 relative overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 flex items-center justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/usamap.png",
                            width: 697,
                            height: 978,
                            alt: ";"
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                            lineNumber: 38,
                            columnNumber: 20
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative z-10 text-center max-w-5xl",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-7xl font-black text-[#2d3e50] leading-tight mb-4",
                                children: [
                                    "YOUR FREIGHT,",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                        lineNumber: 45,
                                        columnNumber: 26
                                    }, this),
                                    "OUR PRIORITY."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 44,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-lg text-gray-600 mb-16",
                                children: [
                                    "We're ready for any honest partnership,",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                        lineNumber: 49,
                                        columnNumber: 52
                                    }, this),
                                    "committed to reliability and trust."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 48,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-12 right-12 flex gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-16 h-12 rounded shadow-md overflow-hidden"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 57,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-16 h-12 rounded shadow-md overflow-hidden",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    viewBox: "0 0 60 40",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            width: "60",
                                            height: "40",
                                            fill: "#fff"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 63,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            width: "15",
                                            height: "40",
                                            fill: "#FF0000"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 64,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            x: "45",
                                            width: "15",
                                            height: "40",
                                            fill: "#FF0000"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M30,10 l2,6 l6,0 l-5,4 l2,6 l-5,-4 l-5,4 l2,-6 l-5,-4 l6,0 z",
                                            fill: "#FF0000"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 66,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                    lineNumber: 62,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 61,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center pb-8 text-gray-600",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-base",
                    children: "Expedite, cross-border, and dedicated logistics across the U.S. and Canada."
                }, void 0, false, {
                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                    lineNumber: 73,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$FleetEqupment$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 79,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Contact$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$About$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_c = HeroSection;
var _c;
__turbopack_context__.k.register(_c, "HeroSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=projects_apex%20landing_apex_src_app_9f37d4bb._.js.map