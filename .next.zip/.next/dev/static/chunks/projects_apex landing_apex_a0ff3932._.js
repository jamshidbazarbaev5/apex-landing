(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_6b87d971._.js",
  "static/chunks/5f7a6_next_dist_compiled_react-dom_af0e8fb0._.js",
  "static/chunks/5f7a6_next_dist_compiled_react-server-dom-turbopack_cbd1cd50._.js",
  "static/chunks/5f7a6_next_dist_compiled_next-devtools_index_34c3df2b.js",
  "static/chunks/5f7a6_next_dist_compiled_70deffd1._.js",
  "static/chunks/5f7a6_next_dist_client_84290909._.js",
  "static/chunks/5f7a6_next_dist_b5c27ab6._.js",
  "static/chunks/5f7a6_@swc_helpers_cjs_cb68391d._.js"
],
    source: "entry"
});
