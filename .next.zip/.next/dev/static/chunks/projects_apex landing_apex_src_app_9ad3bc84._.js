(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TransportServices
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
;
;
function TransportServices() {
    const services = [
        {
            id: 1,
            title: "Full Truckload (FTL)",
            description: "Direct delivery with a dedicated truck and driver, ideal for large shipments.",
            image: "https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?w=800&q=80"
        },
        {
            id: 2,
            title: "Medical Equipment",
            description: "Time-critical and temperature-controlled deliveries for healthcare and hospitals.",
            image: "https://images.unsplash.com/photo-1631815588090-d4bfec5b1ccb?w=800&q=80"
        },
        {
            id: 3,
            title: "Local Courier Deliveries",
            description: "Same-day solutions for documents and small parcels.",
            image: "https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?w=800&q=80"
        },
        {
            id: 4,
            title: "Less-Than-Truckload (LTL)",
            description: "Reliable and cost-efficient transport for smaller shipments.",
            image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800&q=80"
        },
        {
            id: 5,
            title: "Casino & Gaming Equipment",
            description: "Secure, high-value freight handling with dedicated tracking.",
            image: "https://images.unsplash.com/photo-1596838132731-3301c3fd4317?w=800&q=80"
        },
        {
            id: 6,
            title: "Door-to-Door Delivery",
            description: "Convenient and reliable pickup and drop-off service anywhere in the U.S. and Canada.",
            image: "https://images.unsplash.com/photo-1605902711622-cfb43c4437f5?w=800&q=80"
        },
        {
            id: 7,
            title: "Cross-Border Shipping",
            description: "Seamless movement between the U.S. and Canada with customs support.",
            image: "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=800&q=80"
        },
        {
            id: 8,
            title: "Trade Shows & Events",
            description: "On-time setup and breakdown deliveries for exhibitions and conventions.",
            image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&q=80"
        },
        {
            id: 9,
            title: "White Glove Service",
            description: "Premium handling for fragile, high-value, or specialized freight.",
            image: "https://images.unsplash.com/photo-1607400201889-565b1ee75f8e?w=800&q=80"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "e514760edec705be",
                children: ".services-section.jsx-e514760edec705be{background-color:#e8e6e1;padding:80px 40px}.services-container.jsx-e514760edec705be{max-width:1400px;margin:0 auto}.services-header.jsx-e514760edec705be{text-align:center;margin-bottom:60px}.services-title.jsx-e514760edec705be{color:#3d4f5f;margin-bottom:16px;font-size:42px;font-weight:700;line-height:1.3}.services-subtitle.jsx-e514760edec705be{color:#5f6d7a;font-size:18px;line-height:1.6}.services-grid.jsx-e514760edec705be{grid-template-columns:repeat(3,1fr);gap:30px;display:grid}.service-card.jsx-e514760edec705be{cursor:pointer;border-radius:24px;height:280px;transition:transform .3s,box-shadow .3s;position:relative;overflow:hidden}.service-card.jsx-e514760edec705be:hover{transform:translateY(-8px);box-shadow:0 12px 40px #00000026}.service-image.jsx-e514760edec705be{object-fit:cover;width:100%;height:100%}.service-overlay.jsx-e514760edec705be{text-align:center;background:linear-gradient(#0003 0%,#0009 100%);flex-direction:column;justify-content:center;align-items:center;padding:30px;display:flex;position:absolute;inset:0}.service-card-title.jsx-e514760edec705be{color:#fff;text-shadow:0 2px 8px #0000004d;margin-bottom:12px;font-size:24px;font-weight:700}.service-card-description.jsx-e514760edec705be{color:#fff;text-shadow:0 1px 4px #0000004d;font-size:15px;line-height:1.5}@media (width<=1024px){.services-grid.jsx-e514760edec705be{grid-template-columns:repeat(2,1fr)}}@media (width<=640px){.services-section.jsx-e514760edec705be{padding:60px 20px}.services-title.jsx-e514760edec705be{font-size:32px}.services-subtitle.jsx-e514760edec705be{font-size:16px}.services-grid.jsx-e514760edec705be{grid-template-columns:1fr;gap:20px}.service-card.jsx-e514760edec705be{height:240px}.service-card-title.jsx-e514760edec705be{font-size:20px}.service-card-description.jsx-e514760edec705be{font-size:14px}}"
            }, void 0, false, void 0, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "jsx-e514760edec705be" + " " + "services-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "jsx-e514760edec705be" + " " + "services-container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-e514760edec705be" + " " + "services-header",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "jsx-e514760edec705be" + " " + "services-title",
                                    children: "Transport Solutions That Work for You"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                    lineNumber: 192,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "jsx-e514760edec705be" + " " + "services-subtitle",
                                    children: "No matter the load — we deliver safely, on time, and with full visibility."
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                    lineNumber: 195,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                            lineNumber: 191,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-e514760edec705be" + " " + "services-grid",
                            children: services.map((service)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-e514760edec705be" + " " + "service-card",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: service.image,
                                            alt: service.title,
                                            className: "jsx-e514760edec705be" + " " + "service-image"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                            lineNumber: 203,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "jsx-e514760edec705be" + " " + "service-overlay",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "jsx-e514760edec705be" + " " + "service-card-title",
                                                    children: service.title
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                                    lineNumber: 209,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "jsx-e514760edec705be" + " " + "service-card-description",
                                                    children: service.description
                                                }, void 0, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                                    lineNumber: 210,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                            lineNumber: 208,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, service.id, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                                    lineNumber: 202,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                            lineNumber: 200,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                    lineNumber: 190,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                lineNumber: 189,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c = TransportServices;
var _c;
__turbopack_context__.k.register(_c, "TransportServices");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx [app-client] (ecmascript)");
'use client';
;
;
;
function HeroSection() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-[#e8e6e1] flex flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "px-8 py-6 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-10 h-10 relative",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    viewBox: "0 0 40 40",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "8",
                                            cy: "8",
                                            r: "3",
                                            fill: "#2d3748"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 13,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "32",
                                            cy: "8",
                                            r: "3",
                                            fill: "#2d3748"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 14,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "20",
                                            cy: "32",
                                            r: "3",
                                            fill: "#2d3748"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 15,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "8",
                                            y1: "8",
                                            x2: "20",
                                            y2: "32",
                                            stroke: "#2d3748",
                                            strokeWidth: "2"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 16,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "32",
                                            y1: "8",
                                            x2: "20",
                                            y2: "32",
                                            stroke: "#2d3748",
                                            strokeWidth: "2"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 17,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "8",
                                            y1: "8",
                                            x2: "32",
                                            y2: "8",
                                            stroke: "#2d3748",
                                            strokeWidth: "2"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 18,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                    lineNumber: 12,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 11,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-2xl font-semibold text-gray-800",
                                children: "Axper"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 21,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                        lineNumber: 10,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "flex gap-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                className: "text-gray-700 hover:text-gray-900 font-medium",
                                children: "HOME"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 25,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                className: "text-gray-700 hover:text-gray-900 font-medium",
                                children: "SERVICES"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 26,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                className: "text-gray-700 hover:text-gray-900 font-medium",
                                children: "ABOUT US"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 27,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                className: "text-gray-700 hover:text-gray-900 font-medium",
                                children: "APPLICATION"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 28,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#",
                                className: "text-gray-700 hover:text-gray-900 font-medium",
                                children: "CONTACT US"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 29,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "flex-1 flex items-center justify-center px-8 relative overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 flex items-center justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/usamap.png",
                            width: 697,
                            height: 978,
                            alt: ";"
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                            lineNumber: 37,
                            columnNumber: 20
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative z-10 text-center max-w-5xl",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-7xl font-black text-[#2d3e50] leading-tight mb-4",
                                children: [
                                    "YOUR FREIGHT,",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                        lineNumber: 44,
                                        columnNumber: 26
                                    }, this),
                                    "OUR PRIORITY."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 43,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-lg text-gray-600 mb-16",
                                children: [
                                    "We're ready for any honest partnership,",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                        lineNumber: 48,
                                        columnNumber: 52
                                    }, this),
                                    "committed to reliability and trust."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 47,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-12 right-12 flex gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-16 h-12 rounded shadow-md overflow-hidden"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 56,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-16 h-12 rounded shadow-md overflow-hidden",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    viewBox: "0 0 60 40",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            width: "60",
                                            height: "40",
                                            fill: "#fff"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 62,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            width: "15",
                                            height: "40",
                                            fill: "#FF0000"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 63,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            x: "45",
                                            width: "15",
                                            height: "40",
                                            fill: "#FF0000"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 64,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M30,10 l2,6 l6,0 l-5,4 l2,6 l-5,-4 l-5,4 l2,-6 l-5,-4 l6,0 z",
                                            fill: "#FF0000"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                            lineNumber: 65,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                    lineNumber: 61,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                lineNumber: 60,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center pb-8 text-gray-600",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-base",
                    children: "Expedite, cross-border, and dedicated logistics across the U.S. and Canada."
                }, void 0, false, {
                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                    lineNumber: 73,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FleetEquipment, {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = HeroSection;
var _c;
__turbopack_context__.k.register(_c, "HeroSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=projects_apex%20landing_apex_src_app_9ad3bc84._.js.map