(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useScrollAnimation",
    ()=>useScrollAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
const useScrollAnimation = ()=>{
    _s();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useScrollAnimation.useEffect": ()=>{
            const observer = new IntersectionObserver({
                "useScrollAnimation.useEffect": ([entry])=>{
                    if (entry.isIntersecting) {
                        setIsVisible(true);
                        observer.unobserve(entry.target);
                    }
                }
            }["useScrollAnimation.useEffect"], {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            });
            if (ref.current) {
                observer.observe(ref.current);
            }
            return ({
                "useScrollAnimation.useEffect": ()=>{
                    if (ref.current) {
                        observer.unobserve(ref.current);
                    }
                }
            })["useScrollAnimation.useEffect"];
        }
    }["useScrollAnimation.useEffect"], []);
    return {
        ref,
        isVisible
    };
};
_s(useScrollAnimation, "Wk8baY7uc+CWSrD2kMBp+I8qtIg=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FleetEquipment
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function FleetEquipment() {
    _s();
    const { ref, isVisible } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollAnimation"])();
    const vehicles = [
        {
            id: 1,
            name: "Cargo Van",
            image: '/cargovan.png',
            features: [
                "Single covered van",
                "100% insured",
                "Direct & ASAP delivery"
            ]
        },
        {
            id: 2,
            name: "Sprinter Van",
            image: '/cargovan.png',
            features: [
                "More cargo space",
                "GPS-tracked",
                "Ideal for expedited small loads"
            ]
        },
        {
            id: 3,
            name: "Small Straight",
            image: '/cargovan.png',
            features: [
                "Liftgate optional",
                "Perfect for local LTL and residential deliveries",
                "100% insurance"
            ]
        },
        {
            id: 4,
            name: "Straight Truck",
            image: '/cargovan.png',
            features: [
                "Pallet jack & liftgate",
                "Expedited and regional deliveries",
                "Ideal for medical, trade show, or industrial freight"
            ]
        },
        {
            id: 5,
            name: "Semi Truck",
            image: '/cargovan.png',
            features: [
                "Nationwide coverage",
                "Team drivers available",
                "Perfect for large volume and long-haul freight"
            ]
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "671f7b507bb6aa04",
                dynamic: [
                    isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                    isVisible ? 1 : 0
                ],
                children: `@keyframes fadeInDown{0%{opacity:0;transform:translateY(-30px)}to{opacity:1;transform:translateY(0)}}@keyframes scaleIn{0%{opacity:0;transform:scale(.9)}to{opacity:1;transform:scale(1)}}.fleet-section.__jsx-style-dynamic-selector{background-color:#f5f5f5;padding:80px 40px}.fleet-container.__jsx-style-dynamic-selector{max-width:1400px;margin:0 auto}.fleet-header.__jsx-style-dynamic-selector{text-align:center;opacity:${isVisible ? 1 : 0};margin-bottom:60px;animation:${isVisible ? 'fadeInDown 0.6s ease-out' : 'none'}}.fleet-title.__jsx-style-dynamic-selector{color:#3d4f5f;margin-bottom:16px;font-size:42px;font-weight:700;line-height:1.3}.fleet-subtitle.__jsx-style-dynamic-selector{color:#5f6d7a;font-size:18px;line-height:1.6}.fleet-grid.__jsx-style-dynamic-selector{grid-template-columns:repeat(5,1fr);gap:24px;margin-bottom:40px;display:grid}.vehicle-card.__jsx-style-dynamic-selector{background:#fff;border-radius:20px;flex-direction:column;align-items:center;padding:30px 24px;transition:transform .3s,box-shadow .3s;display:flex;box-shadow:0 2px 8px #00000014}.vehicle-card.__jsx-style-dynamic-selector:hover{transform:translateY(-8px);box-shadow:0 8px 24px #0000001f}.vehicle-name.__jsx-style-dynamic-selector{color:#3d4f5f;text-align:center;margin-bottom:24px;font-size:22px;font-weight:700}.vehicle-image-container.__jsx-style-dynamic-selector{justify-content:center;align-items:center;width:100%;height:180px;margin-bottom:32px;display:flex}.vehicle-image.__jsx-style-dynamic-selector{object-fit:contain;width:100%;height:100%}.vehicle-features.__jsx-style-dynamic-selector{width:100%;margin:0;padding:0;list-style:none}.vehicle-feature.__jsx-style-dynamic-selector{color:#6b7280;margin-bottom:12px;padding-left:12px;font-size:15px;line-height:1.6;position:relative}.vehicle-feature.__jsx-style-dynamic-selector:before{content:"–";color:#9ca3af;position:absolute;left:0}.vehicle-feature.__jsx-style-dynamic-selector:last-child{margin-bottom:0}@media (width<=1280px){.fleet-grid.__jsx-style-dynamic-selector{grid-template-columns:repeat(3,1fr)}}@media (width<=768px){.fleet-section.__jsx-style-dynamic-selector{padding:60px 20px}.fleet-title.__jsx-style-dynamic-selector{font-size:32px}.fleet-subtitle.__jsx-style-dynamic-selector{font-size:16px}.fleet-grid.__jsx-style-dynamic-selector{grid-template-columns:repeat(2,1fr);gap:16px}.vehicle-card.__jsx-style-dynamic-selector{padding:24px 16px}.vehicle-name.__jsx-style-dynamic-selector{font-size:18px}.vehicle-image-container.__jsx-style-dynamic-selector{height:140px;margin-bottom:20px}.vehicle-feature.__jsx-style-dynamic-selector{font-size:14px}}@media (width<=480px){.fleet-grid.__jsx-style-dynamic-selector{grid-template-columns:1fr}}`
            }, void 0, false, void 0, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                ref: ref,
                className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "671f7b507bb6aa04",
                        [
                            isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                            isVisible ? 1 : 0
                        ]
                    ]
                ]) + " " + "fleet-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                        [
                            "671f7b507bb6aa04",
                            [
                                isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                isVisible ? 1 : 0
                            ]
                        ]
                    ]) + " " + "fleet-container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                                [
                                    "671f7b507bb6aa04",
                                    [
                                        isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                        isVisible ? 1 : 0
                                    ]
                                ]
                            ]) + " " + "fleet-header",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                                        [
                                            "671f7b507bb6aa04",
                                            [
                                                isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                isVisible ? 1 : 0
                                            ]
                                        ]
                                    ]) + " " + "fleet-title",
                                    children: "Fleet & Equipment Options"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                    lineNumber: 240,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                                        [
                                            "671f7b507bb6aa04",
                                            [
                                                isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                isVisible ? 1 : 0
                                            ]
                                        ]
                                    ]) + " " + "fleet-subtitle",
                                    children: "The right equipment for every type of freight — from local courier runs to cross-country shipments"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                    lineNumber: 243,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                                [
                                    "671f7b507bb6aa04",
                                    [
                                        isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                        isVisible ? 1 : 0
                                    ]
                                ]
                            ]) + " " + "fleet-grid",
                            children: vehicles.map((vehicle, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        animation: isVisible ? `scaleIn 0.5s ease-out ${index * 0.05}s both` : 'none'
                                    },
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                                        [
                                            "671f7b507bb6aa04",
                                            [
                                                isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                isVisible ? 1 : 0
                                            ]
                                        ]
                                    ]) + " " + "vehicle-card",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                                                [
                                                    "671f7b507bb6aa04",
                                                    [
                                                        isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                        isVisible ? 1 : 0
                                                    ]
                                                ]
                                            ]) + " " + "vehicle-name",
                                            children: vehicle.name
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                            lineNumber: 257,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                                                [
                                                    "671f7b507bb6aa04",
                                                    [
                                                        isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                        isVisible ? 1 : 0
                                                    ]
                                                ]
                                            ]) + " " + "vehicle-image-container",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: vehicle.image,
                                                alt: vehicle.name,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                                                    [
                                                        "671f7b507bb6aa04",
                                                        [
                                                            isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                            isVisible ? 1 : 0
                                                        ]
                                                    ]
                                                ]) + " " + "vehicle-image"
                                            }, void 0, false, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                                lineNumber: 259,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                            lineNumber: 258,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                                                [
                                                    "671f7b507bb6aa04",
                                                    [
                                                        isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                        isVisible ? 1 : 0
                                                    ]
                                                ]
                                            ]) + " " + "vehicle-features",
                                            children: vehicle.features.map((feature, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].dynamic([
                                                        [
                                                            "671f7b507bb6aa04",
                                                            [
                                                                isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                                isVisible ? 1 : 0
                                                            ]
                                                        ]
                                                    ]) + " " + "vehicle-feature",
                                                    children: feature
                                                }, index, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                                    lineNumber: 267,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                            lineNumber: 265,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, vehicle.id, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                    lineNumber: 250,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                            lineNumber: 248,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                    lineNumber: 238,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                lineNumber: 237,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(FleetEquipment, "HYNv5rEifZ1S+vJhPkZEtot8gHg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollAnimation"]
    ];
});
_c = FleetEquipment;
var _c;
__turbopack_context__.k.register(_c, "FleetEquipment");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>About
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function About() {
    _s();
    const { ref, isVisible } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollAnimation"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        ref: ref,
        className: "jsx-daa74cbee65d42f" + " " + "about-section",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-daa74cbee65d42f" + " " + "about-container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        style: {
                            animation: isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                            opacity: isVisible ? 1 : 0
                        },
                        className: "jsx-daa74cbee65d42f" + " " + "about-title",
                        children: "About Axper"
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            animation: isVisible ? 'fadeInUp 0.8s ease-out 0.2s both' : 'none'
                        },
                        className: "jsx-daa74cbee65d42f" + " " + "about-content",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-daa74cbee65d42f" + " " + "about-text",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-daa74cbee65d42f",
                                        children: "At Axper, we specialize in dependable, efficient, and flexible logistics solutions across the U.S. and Canada"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 32,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-daa74cbee65d42f",
                                        children: "Whether it's a single box or a full truckload, our experienced team ensures every shipment arrives safely and on time."
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 34,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-daa74cbee65d42f",
                                        children: "With years of experience, a trusted carrier network, and dedicated dispatch professionals, we help businesses streamline their supply chains with reliability and transparency."
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 36,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-daa74cbee65d42f",
                                        children: "Let us handle the logistics — so you can focus on growing your business."
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 38,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                lineNumber: 31,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-daa74cbee65d42f" + " " + "about-branding",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-daa74cbee65d42f" + " " + "axper-logo",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: "/mainlogo.png",
                                        width: 500,
                                        height: 500,
                                        alt: "logo"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 43,
                                        columnNumber: 14
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                    lineNumber: 42,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                lineNumber: 41,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "daa74cbee65d42f",
                children: "@keyframes fadeInDown{0%{opacity:0;transform:translateY(-30px)}to{opacity:1;transform:translateY(0)}}@keyframes fadeInUp{0%{opacity:0;transform:translateY(40px)}to{opacity:1;transform:translateY(0)}}.about-section.jsx-daa74cbee65d42f{background-color:#f5f5f5;justify-content:center;align-items:center;min-height:100vh;padding:80px 40px;display:flex}.about-container.jsx-daa74cbee65d42f{width:100%;max-width:1200px;margin:0 auto}.about-title.jsx-daa74cbee65d42f{text-align:center;color:#2d3e50;letter-spacing:-.5px;margin-bottom:80px;font-size:32px;font-weight:600}.about-content.jsx-daa74cbee65d42f{align-items:center;gap:100px;display:flex}.about-text.jsx-daa74cbee65d42f{flex-direction:column;flex:1;gap:24px;display:flex}.about-text.jsx-daa74cbee65d42f p.jsx-daa74cbee65d42f{color:#666;margin:0;font-family:Geist,sans-serif;font-size:16px;line-height:1.6}.about-branding.jsx-daa74cbee65d42f{flex-direction:column;flex:1;justify-content:center;align-items:center;gap:20px;display:flex}.axper-logo.jsx-daa74cbee65d42f{justify-content:center;align-items:center;width:500px;height:500px;display:flex}.axper-logo.jsx-daa74cbee65d42f svg.jsx-daa74cbee65d42f{width:100%;height:100%}.axper-name.jsx-daa74cbee65d42f{color:#2d3e50;letter-spacing:-1px;margin:20px 0 0;font-size:48px;font-weight:700}.axper-tagline.jsx-daa74cbee65d42f{color:#999;letter-spacing:1px;text-transform:lowercase;margin:0;font-family:Geist,sans-serif;font-size:14px}@media (width<=768px){.about-section.jsx-daa74cbee65d42f{padding:60px 30px}.about-content.jsx-daa74cbee65d42f{flex-direction:column;gap:60px}.about-title.jsx-daa74cbee65d42f{margin-bottom:60px;font-size:28px}.about-text.jsx-daa74cbee65d42f{gap:20px}.about-text.jsx-daa74cbee65d42f p.jsx-daa74cbee65d42f{font-size:15px}.axper-name.jsx-daa74cbee65d42f{font-size:40px}}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_s(About, "HYNv5rEifZ1S+vJhPkZEtot8gHg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollAnimation"]
    ];
});
_c = About;
var _c;
__turbopack_context__.k.register(_c, "About");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/core/styles/contact.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "contactInfo": "contact-module__p3Wiwq__contactInfo",
  "contactSection": "contact-module__p3Wiwq__contactSection",
  "container": "contact-module__p3Wiwq__container",
  "content": "contact-module__p3Wiwq__content",
  "description": "contact-module__p3Wiwq__description",
  "errorMessage": "contact-module__p3Wiwq__errorMessage",
  "form": "contact-module__p3Wiwq__form",
  "formGroup": "contact-module__p3Wiwq__formGroup",
  "heading": "contact-module__p3Wiwq__heading",
  "infoItem": "contact-module__p3Wiwq__infoItem",
  "input": "contact-module__p3Wiwq__input",
  "label": "contact-module__p3Wiwq__label",
  "leftColumn": "contact-module__p3Wiwq__leftColumn",
  "link": "contact-module__p3Wiwq__link",
  "slideIn": "contact-module__p3Wiwq__slideIn",
  "submitBtn": "contact-module__p3Wiwq__submitBtn",
  "successMessage": "contact-module__p3Wiwq__successMessage",
  "tagline": "contact-module__p3Wiwq__tagline",
  "text": "contact-module__p3Wiwq__text",
  "textarea": "contact-module__p3Wiwq__textarea",
});
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Contact
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/styles/contact.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function Contact() {
    _s();
    const { ref, isVisible } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollAnimation"])();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        phone: '',
        email: '',
        message: ''
    });
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [successMessage, setSuccessMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [errorMessage, setErrorMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const handleChange = (e)=>{
        const { name, value } = e.target;
        setFormData((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        setIsLoading(true);
        setSuccessMessage('');
        setErrorMessage('');
        try {
            const response = await fetch('https://axpergroup.com/api/v1/contact-form/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            if (!response.ok) {
                throw new Error('Failed to submit form');
            }
            setSuccessMessage('Message sent successfully! We will contact you soon.');
            setFormData({
                name: '',
                phone: '',
                email: '',
                message: ''
            });
            // Auto-hide success message after 5 seconds
            setTimeout(()=>setSuccessMessage(''), 5000);
        } catch (error) {
            setErrorMessage('Failed to send message. Please try again.');
            console.error('Form submission error:', error);
        } finally{
            setIsLoading(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        ref: ref,
        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactSection || ""),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "a682ee880a7bbb14",
                children: "@keyframes fadeInDown{0%{opacity:0;transform:translateY(-30px)}to{opacity:1;transform:translateY(0)}}@keyframes fadeInLeft{0%{opacity:0;transform:translate(-40px)}to{opacity:1;transform:translate(0)}}@keyframes fadeInRight{0%{opacity:0;transform:translate(40px)}to{opacity:1;transform:translate(0)}}"
            }, void 0, false, void 0, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container || ""),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        style: {
                            animation: isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                            opacity: isVisible ? 1 : 0
                        },
                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].heading || ""),
                        children: "Contact Us"
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content || ""),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    animation: isVisible ? 'fadeInLeft 0.6s ease-out 0.1s both' : 'none'
                                },
                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].leftColumn || ""),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].tagline || ""),
                                        children: "Let's Move Freight Together"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 114,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].description || ""),
                                        children: [
                                            "Have a question or need a quote? We're always ready to help",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {
                                                className: "jsx-a682ee880a7bbb14"
                                            }, void 0, false, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 116,
                                                columnNumber: 74
                                            }, this),
                                            "Call, email, or fill out the form — our team responds within 15 minutes during business hours."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 115,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].contactInfo || ""),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "Company Phone"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 122,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: "tel:(940) 398-0770",
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link || ""),
                                                        children: "(940) 398-0770"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 123,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 121,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "24/7 Operations Phone"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 127,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: "tel:(940) 398-0110",
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link || ""),
                                                        children: "(940) 398-0110"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 128,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 126,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "24/7 Email"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 132,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: "mailto:ops@axpergroup.com",
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].link || ""),
                                                        children: "ops@axpergroup.com"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 133,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 131,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "Address"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 137,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].text || ""),
                                                        children: "1673 Reed Dr, Krum, TX, 76249, US"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 138,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 136,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "MC"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 142,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].text || ""),
                                                        children: "1603523"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 143,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 141,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "USDOT"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 147,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].text || ""),
                                                        children: "4169562"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 148,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 146,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 120,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                lineNumber: 108,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                onSubmit: handleSubmit,
                                style: {
                                    animation: isVisible ? 'fadeInRight 0.6s ease-out 0.1s both' : 'none'
                                },
                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].form || ""),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formGroup || ""),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            name: "name",
                                            placeholder: "Name",
                                            value: formData.name,
                                            onChange: handleChange,
                                            required: true,
                                            className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input || "")
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 161,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 160,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formGroup || ""),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "tel",
                                            name: "phone",
                                            placeholder: "Phone",
                                            value: formData.phone,
                                            onChange: handleChange,
                                            required: true,
                                            className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input || "")
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 173,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 172,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formGroup || ""),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "email",
                                            name: "email",
                                            placeholder: "Email",
                                            value: formData.email,
                                            onChange: handleChange,
                                            required: true,
                                            className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].input || "")
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 185,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 184,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].formGroup || ""),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                            name: "message",
                                            placeholder: "Message",
                                            value: formData.message,
                                            onChange: handleChange,
                                            required: true,
                                            className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].textarea || "")
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 197,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 196,
                                        columnNumber: 13
                                    }, this),
                                    successMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].successMessage || ""),
                                        children: [
                                            "✓ ",
                                            successMessage
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 208,
                                        columnNumber: 15
                                    }, this),
                                    errorMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].errorMessage || ""),
                                        children: [
                                            "✗ ",
                                            errorMessage
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 214,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "submit",
                                        disabled: isLoading,
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].submitBtn || ""),
                                        children: isLoading ? 'Sending...' : 'Submit'
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 219,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                lineNumber: 153,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                lineNumber: 96,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(Contact, "Xhzu6XmWk82uzddyAhDvF5af48k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollAnimation"]
    ];
});
_c = Contact;
var _c;
__turbopack_context__.k.register(_c, "Contact");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Footer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function Footer() {
    _s();
    const { ref, isVisible } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollAnimation"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "footer-container",
        ref: ref,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                children: `
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .footer-container {
          background-color: #3d4a5c;
          padding: 40px 20px;
          text-align: center;
          animation: ${isVisible ? 'fadeInUp 0.6s ease-out' : 'none'};
          opacity: ${isVisible ? 1 : 0};
        }
        
        .footer-content {
          max-width: 1200px;
          margin: 0 auto;
          display: flex;
          gap: 24px;
          justify-content:center;
        }
        
        .social-icons {
          display: flex;
          gap: 20px;
          align-items: center;
        //   justify-content: center;
        }
        
        .social-icons a {
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 44px;
          height: 44px;
          background-color: white;
          border-radius: 4px;
          transition: opacity 0.3s ease;
          color: #3d4a5c;
        }
        
        .social-icons a:hover {
          opacity: 0.85;
        }
        
        .footer-text {
          color: white;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        
        .copyright {
          font-size: 14px;
          font-weight: 500;
          margin: 0;
        }
        
        .tagline {
          font-size: 14px;
          margin: 0;
          opacity: 0.9;
        }
        
        @media (max-width: 768px) {
          .footer-container {
            padding: 30px 20px;
          }
          
          .social-icons {
            gap: 16px;
          }
        }
      `
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "footer-content",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "social-icons",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "https://facebook.com",
                                "aria-label": "Facebook",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "24",
                                    height: "24",
                                    viewBox: "0 0 24 24",
                                    fill: "currentColor",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                        lineNumber: 97,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                    lineNumber: 96,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 95,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "https://instagram.com",
                                "aria-label": "Instagram",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "24",
                                    height: "24",
                                    viewBox: "0 0 24 24",
                                    fill: "currentColor",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            x: "2",
                                            y: "2",
                                            width: "20",
                                            height: "20",
                                            rx: "5",
                                            ry: "5",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "1.5"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                            lineNumber: 102,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "12",
                                            cy: "12",
                                            r: "3.5",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "1.5"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                            lineNumber: 103,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "17",
                                            cy: "7",
                                            r: "0.8",
                                            fill: "currentColor"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                            lineNumber: 104,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                    lineNumber: 101,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 100,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "https://whatsapp.com",
                                "aria-label": "WhatsApp",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "24",
                                    height: "24",
                                    viewBox: "0 0 24 24",
                                    fill: "currentColor",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M12 0C5.4 0 0 5.4 0 12c0 2.1.5 4.1 1.4 5.9L0 24l6.3-1.4c1.7.9 3.7 1.4 5.7 1.4 6.6 0 12-5.4 12-12S18.6 0 12 0zm0 22c-1.9 0-3.7-.5-5.3-1.3l-.4-.2-4.1.9.9-4.1-.2-.4C1.6 15.5 1 13.8 1 12c0-5.5 4.5-10 10-10s10 4.5 10 10-4.5 10-10 10z"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                            lineNumber: 109,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M17.5 13.5c-.3-.1-1.7-.8-2-.9-.3-.1-.5-.1-.7.2-.2.3-.8 1-.9 1.1-.2.2-.3.2-.6.1-.3-.1-1.2-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6.1-.1.3-.4.4-.5.2-.2.2-.3.3-.5.1-.2 0-.4 0-.5-.1-.1-.7-1.6-.9-2.2-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5 0 1.5 1.1 2.9 1.2 3.1.2.2 2.1 3.2 5.1 4.5.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.8-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.1-.3-.2-.6-.3z"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                            lineNumber: 110,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                    lineNumber: 108,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 107,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "https://telegram.org",
                                "aria-label": "Telegram",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "24",
                                    height: "24",
                                    viewBox: "0 0 24 24",
                                    fill: "currentColor",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.161c-.18 1.897-.962 6.5-1.359 8.627-.168.9-.499 1.201-.82 1.23-.697.064-1.228-.46-1.9-.902-1.056-.692-1.653-1.123-2.678-1.799-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.305-3.23.007-.032.015-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.479.329-.913.489-1.302.48-.429-.008-1.252-.242-1.865-.44-.752-.24-1.349-.366-1.297-.775.027-.2.325-.404.893-.612 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635.099-.002.321.023.465.141.12.099.152.232.164.366-.002.11.003.212 0 .329z"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                        lineNumber: 115,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                    lineNumber: 114,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 113,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "footer-text",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "copyright",
                                children: "© 2025 Axper LLC. All rights reserved."
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 120,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "tagline",
                                children: "Reliable logistics. Trusted results."
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 121,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                        lineNumber: 119,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_s(Footer, "HYNv5rEifZ1S+vJhPkZEtot8gHg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollAnimation"]
    ];
});
_c = Footer;
var _c;
__turbopack_context__.k.register(_c, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const Header = ()=>{
    _s();
    const [isScrolled, setIsScrolled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Header.useEffect": ()=>{
            const handleScroll = {
                "Header.useEffect.handleScroll": ()=>{
                    setIsScrolled(window.scrollY > 50);
                }
            }["Header.useEffect.handleScroll"];
            window.addEventListener('scroll', handleScroll);
            return ({
                "Header.useEffect": ()=>window.removeEventListener('scroll', handleScroll)
            })["Header.useEffect"];
        }
    }["Header.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        style: {
            animation: isScrolled ? 'none' : 'slideDown 0.6s ease-out',
            transition: 'all 0.3s ease-out'
        },
        className: "jsx-24e1c2454854532c" + " " + "header",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "24e1c2454854532c",
                children: "@keyframes slideDown{0%{opacity:0;transform:translateY(-20px)}to{opacity:1;transform:translateY(0)}}"
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-24e1c2454854532c" + " " + "header-container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-24e1c2454854532c" + " " + "logo-container",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "homelogo.png",
                            alt: "Axper Logo",
                            className: "jsx-24e1c2454854532c" + " " + "logo"
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                            lineNumber: 41,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "jsx-24e1c2454854532c" + " " + "navigation",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#home",
                                className: "jsx-24e1c2454854532c" + " " + "nav-link",
                                children: "HOME"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                                lineNumber: 44,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#services",
                                className: "jsx-24e1c2454854532c" + " " + "nav-link",
                                children: "SERVICES"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                                lineNumber: 45,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#about",
                                className: "jsx-24e1c2454854532c" + " " + "nav-link",
                                children: "ABOUT US"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                                lineNumber: 46,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#application",
                                className: "jsx-24e1c2454854532c" + " " + "nav-link",
                                children: "APPLICATION"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                                lineNumber: 47,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#contact",
                                className: "jsx-24e1c2454854532c" + " " + "nav-link",
                                children: "CONTACT US"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                                lineNumber: 48,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Header, "UCaI8lpZVGvPrsRoIFYRt2wv0+o=");
_c = Header;
const __TURBOPACK__default__export__ = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const Hero = ()=>{
    _s();
    const { ref, isVisible } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollAnimation"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        ref: ref,
        style: {
            opacity: isVisible ? 1 : 0.8,
            transition: 'opacity 0.6s ease-out'
        },
        className: "jsx-8eef4525c4ca0da8" + " " + "hero",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "8eef4525c4ca0da8",
                children: "@keyframes fadeInUp{0%{opacity:0;transform:translateY(40px)}to{opacity:1;transform:translateY(0)}}"
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-8eef4525c4ca0da8" + " " + "hero-container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        animation: isVisible ? 'fadeInUp 0.8s ease-out' : 'none'
                    },
                    className: "jsx-8eef4525c4ca0da8" + " " + "hero-content",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-8eef4525c4ca0da8" + " " + "map-container",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/usamap.png",
                                alt: "USA Map",
                                className: "jsx-8eef4525c4ca0da8" + " " + "usa-map"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                lineNumber: 40,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                            lineNumber: 39,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-8eef4525c4ca0da8" + " " + "text-overlay",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "jsx-8eef4525c4ca0da8" + " " + "hero-title",
                                    children: [
                                        "YOUR FREIGHT,",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {
                                            className: "jsx-8eef4525c4ca0da8"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                            lineNumber: 44,
                                            columnNumber: 28
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        "OUR PRIORITY."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                    lineNumber: 43,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "jsx-8eef4525c4ca0da8" + " " + "hero-subtitle",
                                    children: [
                                        "We're ready for any honest partnership,",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {
                                            className: "jsx-8eef4525c4ca0da8"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                            lineNumber: 48,
                                            columnNumber: 54
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        "committed to reliability and trust."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                    lineNumber: 47,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-8eef4525c4ca0da8" + " " + "bottom-section",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-8eef4525c4ca0da8" + " " + "flags-container",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/usacanada.png",
                                    alt: "USA and Canada Flags",
                                    className: "jsx-8eef4525c4ca0da8" + " " + "flags"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                    lineNumber: 56,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                lineNumber: 55,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                            lineNumber: 53,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                zIndex: "1",
                                marginTop: 10
                            },
                            className: "jsx-8eef4525c4ca0da8",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "jsx-8eef4525c4ca0da8" + " " + "bottom-text",
                                children: "Expedite, cross-border, and dedicated logistics across the U.S. and Canada."
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                lineNumber: 60,
                                columnNumber: 14
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                            lineNumber: 59,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Hero, "HYNv5rEifZ1S+vJhPkZEtot8gHg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollAnimation"]
    ];
});
_c = Hero;
const __TURBOPACK__default__export__ = Hero;
var _c;
__turbopack_context__.k.register(_c, "Hero");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/projects/apex landing/apex/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$FleetEqupment$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$About$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Contact$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Hero$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
function HeroSection() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: " bg-[#F5F5F5] flex flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 14,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Hero$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 15,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ServiceCard, {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$FleetEqupment$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$About$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Contact$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = HeroSection;
var _c;
__turbopack_context__.k.register(_c, "HeroSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=projects_apex%20landing_apex_src_app_f87256ff._.js.map