__turbopack_load_page_chunks__("/_error", [
  "static/chunks/5f7a6_next_dist_compiled_e58e4e44._.js",
  "static/chunks/5f7a6_next_dist_shared_lib_51d0e3c4._.js",
  "static/chunks/5f7a6_next_dist_client_623b175b._.js",
  "static/chunks/5f7a6_next_dist_862a3ddc._.js",
  "static/chunks/5f7a6_next_error_67eff894.js",
  "static/chunks/[next]_entry_page-loader_ts_e975fad5._.js",
  "static/chunks/5f7a6_react-dom_bbd9eb6f._.js",
  "static/chunks/5f7a6_1c4ebd12._.js",
  "static/chunks/[root-of-the-server]__b0e757f5._.js",
  "static/chunks/projects_apex landing_apex_pages__error_2da965e7._.js",
  "static/chunks/turbopack-projects_apex landing_apex_pages__error_fff19482._.js"
])
