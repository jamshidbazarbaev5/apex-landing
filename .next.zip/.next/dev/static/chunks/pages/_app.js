__turbopack_load_page_chunks__("/_app", [
  "static/chunks/5f7a6_next_dist_compiled_e58e4e44._.js",
  "static/chunks/5f7a6_next_dist_shared_lib_7b49586d._.js",
  "static/chunks/5f7a6_next_dist_client_623b175b._.js",
  "static/chunks/5f7a6_next_dist_a69cf88c._.js",
  "static/chunks/5f7a6_next_app_f1049eb8.js",
  "static/chunks/[next]_entry_page-loader_ts_510ae0cc._.js",
  "static/chunks/5f7a6_react-dom_bbd9eb6f._.js",
  "static/chunks/5f7a6_1c4ebd12._.js",
  "static/chunks/[root-of-the-server]__380da973._.js",
  "static/chunks/projects_apex landing_apex_pages__app_2da965e7._.js",
  "static/chunks/turbopack-projects_apex landing_apex_pages__app_82cc1b1d._.js"
])
