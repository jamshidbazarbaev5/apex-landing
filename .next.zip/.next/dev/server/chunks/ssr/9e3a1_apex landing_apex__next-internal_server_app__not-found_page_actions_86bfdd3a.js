module.exports = [
"[project]/projects/apex landing/apex/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=9e3a1_apex%20landing_apex__next-internal_server_app__not-found_page_actions_86bfdd3a.js.map