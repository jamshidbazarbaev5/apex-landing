module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ServiceCard",
    ()=>ServiceCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const ServiceCard = ({ item })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "group relative w-full h-64 sm:h-72 lg:h-60 overflow-hidden rounded-[2.5rem] shadow-xl transition-all duration-300 hover:shadow-2xl hover:-translate-y-1",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: item?.image,
                alt: item?.title,
                className: "absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-in-out group-hover:scale-110"
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                lineNumber: 12,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `absolute inset-0 ${item?.tintClass} transition-all duration-300`
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/10 opacity-80"
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 z-10 flex flex-col justify-center items-center p-6 sm:p-8 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-white text-xl sm:text-2xl font-bold mb-3 drop-shadow-lg tracking-wide",
                        children: item?.title
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-100 text-sm sm:text-[0.95rem] leading-snug max-w-[280px] drop-shadow-md font-normal opacity-95",
                        children: item.description
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                        lineNumber: 31,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
}),
"[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useScrollAnimation",
    ()=>useScrollAnimation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
const useScrollAnimation = ()=>{
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const observer = new IntersectionObserver(([entry])=>{
            if (entry.isIntersecting) {
                setIsVisible(true);
                observer.unobserve(entry.target);
            }
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });
        if (ref.current) {
            observer.observe(ref.current);
        }
        return ()=>{
            if (ref.current) {
                observer.unobserve(ref.current);
            }
        };
    }, []);
    return {
        ref,
        isVisible
    };
};
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FleetEquipment
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
function FleetEquipment() {
    const { ref, isVisible } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useScrollAnimation"])();
    const vehicles = [
        {
            id: 1,
            name: "Cargo Van",
            image: '/cargovan.png',
            features: [
                "Single covered van",
                "100% insured",
                "Direct & ASAP delivery"
            ]
        },
        {
            id: 2,
            name: "Sprinter Van",
            image: '/sprinter.png',
            features: [
                "More cargo space",
                "GPS-tracked",
                "Ideal for expedited small loads"
            ]
        },
        {
            id: 3,
            name: "Small Straight",
            image: '/cargovan.png',
            features: [
                "Liftgate optional",
                "Perfect for local LTL and residential deliveries",
                "100% insurance"
            ]
        },
        {
            id: 4,
            name: "Straight Truck",
            image: '/straight.png',
            features: [
                "Pallet jack & liftgate",
                "Expedited and regional deliveries",
                "Ideal for medical, trade show, or industrial freight"
            ]
        },
        {
            id: 5,
            name: "Semi Truck",
            image: '/dry.png',
            features: [
                "Nationwide coverage",
                "Team drivers available",
                "Perfect for large volume and long-haul freight"
            ]
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "671f7b507bb6aa04",
                dynamic: [
                    isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                    isVisible ? 1 : 0
                ],
                children: `@keyframes fadeInDown{0%{opacity:0;transform:translateY(-30px)}to{opacity:1;transform:translateY(0)}}@keyframes scaleIn{0%{opacity:0;transform:scale(.9)}to{opacity:1;transform:scale(1)}}.fleet-section.__jsx-style-dynamic-selector{background-color:#f5f5f5;padding:80px 40px}.fleet-container.__jsx-style-dynamic-selector{max-width:1400px;margin:0 auto}.fleet-header.__jsx-style-dynamic-selector{text-align:center;opacity:${isVisible ? 1 : 0};margin-bottom:60px;animation:${isVisible ? 'fadeInDown 0.6s ease-out' : 'none'}}.fleet-title.__jsx-style-dynamic-selector{color:#3d4f5f;margin-bottom:16px;font-size:42px;font-weight:700;line-height:1.3}.fleet-subtitle.__jsx-style-dynamic-selector{color:#5f6d7a;font-size:18px;line-height:1.6}.fleet-grid.__jsx-style-dynamic-selector{grid-template-columns:repeat(5,1fr);gap:24px;margin-bottom:40px;display:grid}.vehicle-card.__jsx-style-dynamic-selector{background:#fff;border-radius:20px;flex-direction:column;align-items:center;padding:30px 24px;transition:transform .3s,box-shadow .3s;display:flex;box-shadow:0 2px 8px #00000014}.vehicle-card.__jsx-style-dynamic-selector:hover{transform:translateY(-8px);box-shadow:0 8px 24px #0000001f}.vehicle-name.__jsx-style-dynamic-selector{color:#3d4f5f;text-align:center;margin-bottom:24px;font-size:22px;font-weight:700}.vehicle-image-container.__jsx-style-dynamic-selector{justify-content:center;align-items:center;width:100%;height:180px;margin-bottom:32px;display:flex}.vehicle-image.__jsx-style-dynamic-selector{object-fit:contain;width:100%;height:100%}.vehicle-features.__jsx-style-dynamic-selector{width:100%;margin:0;padding:0;list-style:none}.vehicle-feature.__jsx-style-dynamic-selector{color:#6b7280;margin-bottom:12px;padding-left:12px;font-size:15px;line-height:1.6;position:relative}.vehicle-feature.__jsx-style-dynamic-selector:before{content:"–";color:#9ca3af;position:absolute;left:0}.vehicle-feature.__jsx-style-dynamic-selector:last-child{margin-bottom:0}@media (width<=1280px){.fleet-grid.__jsx-style-dynamic-selector{grid-template-columns:repeat(3,1fr)}}@media (width<=768px){.fleet-section.__jsx-style-dynamic-selector{padding:60px 20px}.fleet-title.__jsx-style-dynamic-selector{font-size:32px}.fleet-subtitle.__jsx-style-dynamic-selector{font-size:16px}.fleet-grid.__jsx-style-dynamic-selector{grid-template-columns:repeat(2,1fr);gap:16px}.vehicle-card.__jsx-style-dynamic-selector{padding:24px 16px}.vehicle-name.__jsx-style-dynamic-selector{font-size:18px}.vehicle-image-container.__jsx-style-dynamic-selector{height:140px;margin-bottom:20px}.vehicle-feature.__jsx-style-dynamic-selector{font-size:14px}}@media (width<=480px){.fleet-grid.__jsx-style-dynamic-selector{grid-template-columns:1fr}}`
            }, void 0, false, void 0, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                ref: ref,
                className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "671f7b507bb6aa04",
                        [
                            isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                            isVisible ? 1 : 0
                        ]
                    ]
                ]) + " " + "fleet-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                        [
                            "671f7b507bb6aa04",
                            [
                                isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                isVisible ? 1 : 0
                            ]
                        ]
                    ]) + " " + "fleet-container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                [
                                    "671f7b507bb6aa04",
                                    [
                                        isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                        isVisible ? 1 : 0
                                    ]
                                ]
                            ]) + " " + "fleet-header",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                        [
                                            "671f7b507bb6aa04",
                                            [
                                                isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                isVisible ? 1 : 0
                                            ]
                                        ]
                                    ]) + " " + "fleet-title",
                                    children: "Fleet & Equipment Options"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                    lineNumber: 240,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                        [
                                            "671f7b507bb6aa04",
                                            [
                                                isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                isVisible ? 1 : 0
                                            ]
                                        ]
                                    ]) + " " + "fleet-subtitle",
                                    children: "The right equipment for every type of freight — from local courier runs to cross-country shipments"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                    lineNumber: 243,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                [
                                    "671f7b507bb6aa04",
                                    [
                                        isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                        isVisible ? 1 : 0
                                    ]
                                ]
                            ]) + " " + "fleet-grid",
                            children: vehicles.map((vehicle, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        animation: isVisible ? `scaleIn 0.5s ease-out ${index * 0.05}s both` : 'none'
                                    },
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                        [
                                            "671f7b507bb6aa04",
                                            [
                                                isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                isVisible ? 1 : 0
                                            ]
                                        ]
                                    ]) + " " + "vehicle-card",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                                [
                                                    "671f7b507bb6aa04",
                                                    [
                                                        isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                        isVisible ? 1 : 0
                                                    ]
                                                ]
                                            ]) + " " + "vehicle-name",
                                            children: vehicle.name
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                            lineNumber: 257,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                                [
                                                    "671f7b507bb6aa04",
                                                    [
                                                        isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                        isVisible ? 1 : 0
                                                    ]
                                                ]
                                            ]) + " " + "vehicle-image-container",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: vehicle.image,
                                                alt: vehicle.name,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                                    [
                                                        "671f7b507bb6aa04",
                                                        [
                                                            isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                            isVisible ? 1 : 0
                                                        ]
                                                    ]
                                                ]) + " " + "vehicle-image"
                                            }, void 0, false, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                                lineNumber: 259,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                            lineNumber: 258,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                                [
                                                    "671f7b507bb6aa04",
                                                    [
                                                        isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                        isVisible ? 1 : 0
                                                    ]
                                                ]
                                            ]) + " " + "vehicle-features",
                                            children: vehicle.features.map((feature, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                                        [
                                                            "671f7b507bb6aa04",
                                                            [
                                                                isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                                                                isVisible ? 1 : 0
                                                            ]
                                                        ]
                                                    ]) + " " + "vehicle-feature",
                                                    children: feature
                                                }, index, false, {
                                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                                    lineNumber: 267,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                            lineNumber: 265,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, vehicle.id, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                                    lineNumber: 250,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                            lineNumber: 248,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                    lineNumber: 238,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx",
                lineNumber: 237,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>About
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
;
function About() {
    const { ref, isVisible } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useScrollAnimation"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        ref: ref,
        className: "jsx-daa74cbee65d42f" + " " + "about-section",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-daa74cbee65d42f" + " " + "about-container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        style: {
                            animation: isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                            opacity: isVisible ? 1 : 0
                        },
                        className: "jsx-daa74cbee65d42f" + " " + "about-title",
                        children: "About Axper"
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            animation: isVisible ? 'fadeInUp 0.8s ease-out 0.2s both' : 'none'
                        },
                        className: "jsx-daa74cbee65d42f" + " " + "about-content",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-daa74cbee65d42f" + " " + "about-text",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-daa74cbee65d42f",
                                        children: "At Axper, we specialize in dependable, efficient, and flexible logistics solutions across the U.S. and Canada"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 32,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-daa74cbee65d42f",
                                        children: "Whether it's a single box or a full truckload, our experienced team ensures every shipment arrives safely and on time."
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 34,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-daa74cbee65d42f",
                                        children: "With years of experience, a trusted carrier network, and dedicated dispatch professionals, we help businesses streamline their supply chains with reliability and transparency."
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 36,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-daa74cbee65d42f",
                                        children: "Let us handle the logistics — so you can focus on growing your business."
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 38,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                lineNumber: 31,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-daa74cbee65d42f" + " " + "about-branding",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-daa74cbee65d42f" + " " + "axper-logo",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        src: "/mainlogo.png",
                                        width: 500,
                                        height: 500,
                                        alt: "logo"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                        lineNumber: 43,
                                        columnNumber: 14
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                    lineNumber: 42,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                                lineNumber: 41,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "daa74cbee65d42f",
                children: "@keyframes fadeInDown{0%{opacity:0;transform:translateY(-30px)}to{opacity:1;transform:translateY(0)}}@keyframes fadeInUp{0%{opacity:0;transform:translateY(40px)}to{opacity:1;transform:translateY(0)}}.about-section.jsx-daa74cbee65d42f{background-color:#f5f5f5;justify-content:center;align-items:center;min-height:100vh;padding:80px 40px;display:flex}.about-container.jsx-daa74cbee65d42f{width:100%;max-width:1200px;margin:0 auto}.about-title.jsx-daa74cbee65d42f{text-align:center;color:#2d3e50;letter-spacing:-.5px;margin-bottom:80px;font-size:32px;font-weight:600}.about-content.jsx-daa74cbee65d42f{align-items:center;gap:100px;display:flex}.about-text.jsx-daa74cbee65d42f{flex-direction:column;flex:1;gap:24px;display:flex}.about-text.jsx-daa74cbee65d42f p.jsx-daa74cbee65d42f{color:#666;margin:0;font-family:Geist,sans-serif;font-size:16px;line-height:1.6}.about-branding.jsx-daa74cbee65d42f{flex-direction:column;flex:1;justify-content:center;align-items:center;gap:20px;display:flex}.axper-logo.jsx-daa74cbee65d42f{justify-content:center;align-items:center;width:500px;height:500px;display:flex}.axper-logo.jsx-daa74cbee65d42f svg.jsx-daa74cbee65d42f{width:100%;height:100%}.axper-name.jsx-daa74cbee65d42f{color:#2d3e50;letter-spacing:-1px;margin:20px 0 0;font-size:48px;font-weight:700}.axper-tagline.jsx-daa74cbee65d42f{color:#999;letter-spacing:1px;text-transform:lowercase;margin:0;font-family:Geist,sans-serif;font-size:14px}@media (width<=768px){.about-section.jsx-daa74cbee65d42f{padding:60px 30px}.about-content.jsx-daa74cbee65d42f{flex-direction:column;gap:60px}.about-title.jsx-daa74cbee65d42f{margin-bottom:60px;font-size:28px}.about-text.jsx-daa74cbee65d42f{gap:20px}.about-text.jsx-daa74cbee65d42f p.jsx-daa74cbee65d42f{font-size:15px}.axper-name.jsx-daa74cbee65d42f{font-size:40px}}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
}),
"[project]/projects/apex landing/apex/src/app/core/styles/contact.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "contactInfo": "contact-module__p3Wiwq__contactInfo",
  "contactSection": "contact-module__p3Wiwq__contactSection",
  "container": "contact-module__p3Wiwq__container",
  "content": "contact-module__p3Wiwq__content",
  "description": "contact-module__p3Wiwq__description",
  "errorMessage": "contact-module__p3Wiwq__errorMessage",
  "form": "contact-module__p3Wiwq__form",
  "formGroup": "contact-module__p3Wiwq__formGroup",
  "heading": "contact-module__p3Wiwq__heading",
  "infoItem": "contact-module__p3Wiwq__infoItem",
  "input": "contact-module__p3Wiwq__input",
  "label": "contact-module__p3Wiwq__label",
  "leftColumn": "contact-module__p3Wiwq__leftColumn",
  "link": "contact-module__p3Wiwq__link",
  "slideIn": "contact-module__p3Wiwq__slideIn",
  "submitBtn": "contact-module__p3Wiwq__submitBtn",
  "successMessage": "contact-module__p3Wiwq__successMessage",
  "tagline": "contact-module__p3Wiwq__tagline",
  "text": "contact-module__p3Wiwq__text",
  "textarea": "contact-module__p3Wiwq__textarea",
});
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Contact
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/styles/contact.module.css [app-ssr] (css module)");
'use client';
;
;
;
;
;
function Contact() {
    const { ref, isVisible } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useScrollAnimation"])();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        phone: '',
        email: '',
        message: ''
    });
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [successMessage, setSuccessMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [errorMessage, setErrorMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const handleChange = (e)=>{
        const { name, value } = e.target;
        setFormData((prev)=>({
                ...prev,
                [name]: value
            }));
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        setIsLoading(true);
        setSuccessMessage('');
        setErrorMessage('');
        try {
            const response = await fetch('https://axpergroup.com/api/v1/contact-form/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            if (!response.ok) {
                throw new Error('Failed to submit form');
            }
            setSuccessMessage('Message sent successfully! We will contact you soon.');
            setFormData({
                name: '',
                phone: '',
                email: '',
                message: ''
            });
            // Auto-hide success message after 5 seconds
            setTimeout(()=>setSuccessMessage(''), 5000);
        } catch (error) {
            setErrorMessage('Failed to send message. Please try again.');
            console.error('Form submission error:', error);
        } finally{
            setIsLoading(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        ref: ref,
        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].contactSection || ""),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "a682ee880a7bbb14",
                children: "@keyframes fadeInDown{0%{opacity:0;transform:translateY(-30px)}to{opacity:1;transform:translateY(0)}}@keyframes fadeInLeft{0%{opacity:0;transform:translate(-40px)}to{opacity:1;transform:translate(0)}}@keyframes fadeInRight{0%{opacity:0;transform:translate(40px)}to{opacity:1;transform:translate(0)}}"
            }, void 0, false, void 0, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].container || ""),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        style: {
                            animation: isVisible ? 'fadeInDown 0.6s ease-out' : 'none',
                            opacity: isVisible ? 1 : 0
                        },
                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].heading || ""),
                        children: "Contact Us"
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].content || ""),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    animation: isVisible ? 'fadeInLeft 0.6s ease-out 0.1s both' : 'none'
                                },
                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].leftColumn || ""),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].tagline || ""),
                                        children: "Let's Move Freight Together"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 114,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].description || ""),
                                        children: [
                                            "Have a question or need a quote? We're always ready to help",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {
                                                className: "jsx-a682ee880a7bbb14"
                                            }, void 0, false, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 116,
                                                columnNumber: 74
                                            }, this),
                                            "Call, email, or fill out the form — our team responds within 15 minutes during business hours."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 115,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].contactInfo || ""),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "Company Phone"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 122,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: "tel:(940) 398-0770",
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].link || ""),
                                                        children: "(940) 398-0770"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 123,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 121,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "24/7 Operations Phone"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 127,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: "tel:(940) 398-0110",
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].link || ""),
                                                        children: "(940) 398-0110"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 128,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 126,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "24/7 Email"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 132,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: "mailto:ops@axpergroup.com",
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].link || ""),
                                                        children: "ops@axpergroup.com"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 133,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 131,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "Address"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 137,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].text || ""),
                                                        children: "1673 Reed Dr, Krum, TX, 76249, US"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 138,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 136,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "MC"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 142,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].text || ""),
                                                        children: "1603523"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 143,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 141,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].infoItem || ""),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label || ""),
                                                        children: "USDOT"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 147,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].text || ""),
                                                        children: "4169562"
                                                    }, void 0, false, {
                                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                        lineNumber: 148,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                                lineNumber: 146,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 120,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                lineNumber: 108,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                onSubmit: handleSubmit,
                                style: {
                                    animation: isVisible ? 'fadeInRight 0.6s ease-out 0.1s both' : 'none'
                                },
                                className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].form || ""),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].formGroup || ""),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            name: "name",
                                            placeholder: "Name",
                                            value: formData.name,
                                            onChange: handleChange,
                                            required: true,
                                            className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].input || "")
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 161,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 160,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].formGroup || ""),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "tel",
                                            name: "phone",
                                            placeholder: "Phone",
                                            value: formData.phone,
                                            onChange: handleChange,
                                            required: true,
                                            className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].input || "")
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 173,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 172,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].formGroup || ""),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "email",
                                            name: "email",
                                            placeholder: "Email",
                                            value: formData.email,
                                            onChange: handleChange,
                                            required: true,
                                            className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].input || "")
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 185,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 184,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].formGroup || ""),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                            name: "message",
                                            placeholder: "Message",
                                            value: formData.message,
                                            onChange: handleChange,
                                            required: true,
                                            className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].textarea || "")
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                            lineNumber: 197,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 196,
                                        columnNumber: 13
                                    }, this),
                                    successMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].successMessage || ""),
                                        children: [
                                            "✓ ",
                                            successMessage
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 208,
                                        columnNumber: 15
                                    }, this),
                                    errorMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].errorMessage || ""),
                                        children: [
                                            "✗ ",
                                            errorMessage
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 214,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "submit",
                                        disabled: isLoading,
                                        className: "jsx-a682ee880a7bbb14" + " " + (__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$styles$2f$contact$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].submitBtn || ""),
                                        children: isLoading ? 'Sending...' : 'Submit'
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                        lineNumber: 219,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                                lineNumber: 153,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
                lineNumber: 96,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Footer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-ssr] (ecmascript)");
'use client';
;
;
function Footer() {
    const { ref, isVisible } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useScrollAnimation"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "footer-container",
        ref: ref,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                children: `
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .footer-container {
          background-color: #3d4a5c;
          padding: 40px 20px;
          text-align: center;
          animation: ${isVisible ? 'fadeInUp 0.6s ease-out' : 'none'};
          opacity: ${isVisible ? 1 : 0};
        }
        
        .footer-content {
          max-width: 1200px;
          margin: 0 auto;
          display: flex;
          gap: 24px;
          justify-content: center;
          align-items: center;
          flex-wrap: wrap;
        }
        
        .social-icons {
          display: flex;
          gap: 16px;
          align-items: center;
          justify-content: center;
        }
        
        .social-icons a {
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 44px;
          height: 44px;
          background-color: white;
          border-radius: 4px;
          transition: opacity 0.3s ease;
          color: #3d4a5c;
        }
        
        .social-icons a:hover {
          opacity: 0.85;
        }
        
        .footer-text {
          color: white;
          display: flex;
          flex-direction: column;
          gap: 8px;
          text-align: center;
        }
        
        .copyright {
          font-size: 14px;
          font-weight: 500;
          margin: 0;
        }
        
        .tagline {
          font-size: 14px;
          margin: 0;
          opacity: 0.9;
        }
        
        @media (max-width: 768px) {
          .footer-container {
            padding: 30px 20px;
          }
          
          .footer-content {
            flex-direction: column;
            gap: 20px;
          }
          
          .social-icons {
            gap: 12px;
          }

          .social-icons a {
            width: 40px;
            height: 40px;
          }

          .copyright {
            font-size: 12px;
          }

          .tagline {
            font-size: 12px;
          }
        }

        @media (max-width: 480px) {
          .footer-container {
            padding: 24px 16px;
          }

          .footer-content {
            gap: 16px;
          }

          .social-icons {
            gap: 10px;
          }

          .social-icons a {
            width: 36px;
            height: 36px;
          }

          .social-icons svg {
            width: 18px;
            height: 18px;
          }

          .copyright {
            font-size: 11px;
          }

          .tagline {
            font-size: 11px;
          }
        }
      `
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "footer-content",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "social-icons",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "https://www.facebook.com/axpergroup/",
                                "aria-label": "Facebook",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "24",
                                    height: "24",
                                    viewBox: "0 0 24 24",
                                    fill: "currentColor",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                        lineNumber: 150,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                    lineNumber: 149,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 148,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "https://www.instagram.com/axpergroup/",
                                "aria-label": "Instagram",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "24",
                                    height: "24",
                                    viewBox: "0 0 24 24",
                                    fill: "currentColor",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            x: "2",
                                            y: "2",
                                            width: "20",
                                            height: "20",
                                            rx: "5",
                                            ry: "5",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "1.5"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                            lineNumber: 155,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "12",
                                            cy: "12",
                                            r: "3.5",
                                            fill: "none",
                                            stroke: "currentColor",
                                            strokeWidth: "1.5"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                            lineNumber: 156,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                            cx: "17",
                                            cy: "7",
                                            r: "0.8",
                                            fill: "currentColor"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                            lineNumber: 157,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                    lineNumber: 154,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 153,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "https://t.me/axpergroup",
                                "aria-label": "Telegram",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "24",
                                    height: "24",
                                    viewBox: "0 0 24 24",
                                    fill: "currentColor",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        d: "M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.161c-.18 1.897-.962 6.5-1.359 8.627-.168.9-.499 1.201-.82 1.23-.697.064-1.228-.46-1.9-.902-1.056-.692-1.653-1.123-2.678-1.799-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.305-3.23.007-.032.015-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.479.329-.913.489-1.302.48-.429-.008-1.252-.242-1.865-.44-.752-.24-1.349-.366-1.297-.775.027-.2.325-.404.893-.612 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635.099-.002.321.023.465.141.12.099.152.232.164.366-.002.11.003.212 0 .329z"
                                    }, void 0, false, {
                                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                        lineNumber: 162,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                    lineNumber: 161,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 160,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                        lineNumber: 147,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "footer-text",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "copyright",
                                children: "© 2025 Axper LLC. All rights reserved."
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 167,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "tagline",
                                children: "Reliable logistics. Trusted results."
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                                lineNumber: 168,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                        lineNumber: 166,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
                lineNumber: 146,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
const Header = ()=>{
    const [isScrolled, setIsScrolled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleScroll = ()=>{
            setIsScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return ()=>window.removeEventListener('scroll', handleScroll);
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        style: {
            animation: isScrolled ? 'none' : 'slideDown 0.6s ease-out',
            transition: 'all 0.3s ease-out'
        },
        className: "jsx-24e1c2454854532c" + " " + "header",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "24e1c2454854532c",
                children: "@keyframes slideDown{0%{opacity:0;transform:translateY(-20px)}to{opacity:1;transform:translateY(0)}}"
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-24e1c2454854532c" + " " + "header-container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-24e1c2454854532c" + " " + "logo-container",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "homelogo.png",
                            alt: "Axper Logo",
                            className: "jsx-24e1c2454854532c" + " " + "logo"
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                            lineNumber: 41,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "jsx-24e1c2454854532c" + " " + "navigation",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#home",
                                className: "jsx-24e1c2454854532c" + " " + "nav-link",
                                children: "HOME"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                                lineNumber: 44,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#services",
                                className: "jsx-24e1c2454854532c" + " " + "nav-link",
                                children: "SERVICES"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                                lineNumber: 45,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#fleet",
                                className: "jsx-24e1c2454854532c" + " " + "nav-link",
                                children: "FLEET"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                                lineNumber: 46,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#about",
                                className: "jsx-24e1c2454854532c" + " " + "nav-link",
                                children: "ABOUT US"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                                lineNumber: 47,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "#contact",
                                className: "jsx-24e1c2454854532c" + " " + "nav-link",
                                children: "CONTACT US"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                                lineNumber: 48,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Header;
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/animations/useScrollAnimation.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
;
const Hero = ()=>{
    const { ref, isVisible } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$animations$2f$useScrollAnimation$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useScrollAnimation"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        ref: ref,
        style: {
            opacity: isVisible ? 1 : 0.8,
            transition: 'opacity 0.6s ease-out'
        },
        className: "jsx-8eef4525c4ca0da8" + " " + "hero",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "8eef4525c4ca0da8",
                children: "@keyframes fadeInUp{0%{opacity:0;transform:translateY(40px)}to{opacity:1;transform:translateY(0)}}"
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-8eef4525c4ca0da8" + " " + "hero-container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        animation: isVisible ? 'fadeInUp 0.8s ease-out' : 'none'
                    },
                    className: "jsx-8eef4525c4ca0da8" + " " + "hero-content",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-8eef4525c4ca0da8" + " " + "map-container",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/usamap.png",
                                alt: "USA Map",
                                className: "jsx-8eef4525c4ca0da8" + " " + "usa-map"
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                lineNumber: 40,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                            lineNumber: 39,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-8eef4525c4ca0da8" + " " + "text-overlay",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "jsx-8eef4525c4ca0da8" + " " + "hero-title",
                                    children: [
                                        "YOUR FREIGHT,",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {
                                            className: "jsx-8eef4525c4ca0da8"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                            lineNumber: 44,
                                            columnNumber: 28
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        "OUR PRIORITY."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                    lineNumber: 43,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "jsx-8eef4525c4ca0da8" + " " + "hero-subtitle",
                                    children: [
                                        "We're ready for any honest partnership,",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {
                                            className: "jsx-8eef4525c4ca0da8"
                                        }, void 0, false, {
                                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                            lineNumber: 48,
                                            columnNumber: 54
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        "committed to reliability and trust."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                    lineNumber: 47,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-8eef4525c4ca0da8" + " " + "bottom-section",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-8eef4525c4ca0da8" + " " + "flags-container",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/usacanada.png",
                                    alt: "USA and Canada Flags",
                                    className: "jsx-8eef4525c4ca0da8" + " " + "flags"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                    lineNumber: 56,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                lineNumber: 55,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                            lineNumber: 53,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                zIndex: "1",
                                marginTop: 10
                            },
                            className: "jsx-8eef4525c4ca0da8",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "jsx-8eef4525c4ca0da8" + " " + "bottom-text",
                                children: "Expedite, cross-border, and dedicated logistics across the U.S. and Canada."
                            }, void 0, false, {
                                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                                lineNumber: 60,
                                columnNumber: 14
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                            lineNumber: 59,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Hero;
}),
"[project]/projects/apex landing/apex/src/app/core/blocks/constants.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SERVICES",
    ()=>SERVICES
]);
const SERVICES = [
    {
        title: 'Full Truckload (FTL)',
        description: 'Direct delivery with a dedicated truck and driver, ideal for large shipments.',
        image: '/FTL.jpg',
        tintClass: 'bg-black/70'
    },
    {
        title: 'Medical Equipment',
        description: 'Time-critical and temperature-controlled deliveries for healthcare and hospitals.',
        image: 'medical.jpg',
        tintClass: 'bg-cyan-900/80'
    },
    {
        title: 'Local Courier Deliveries',
        description: 'Same-day solutions for documents and small parcels.',
        image: 'local.jpg',
        tintClass: 'bg-stone-900/75'
    },
    {
        title: 'Less-Than-Truckload (LTL)',
        description: 'Reliable and cost-efficient transport for smaller shipments.',
        image: 'LTL.jpg',
        tintClass: 'bg-amber-950/80'
    },
    {
        title: 'Casino & Gaming Equipment',
        description: 'Secure, high-value freight handling with dedicated tracking.',
        image: 'casino.jpg',
        tintClass: 'bg-indigo-950/80'
    },
    {
        title: 'Door-to-Door Delivery',
        description: 'Convenient and reliable pickup and drop-off service anywhere in the U.S. and Canada.',
        image: 'door.jpg',
        tintClass: 'bg-slate-700/75'
    },
    {
        title: 'Cross-Border Shipping',
        description: 'Seamless movement between the U.S. and Canada with customs support.',
        image: 'Border.jpg',
        tintClass: 'bg-emerald-900/80'
    },
    {
        title: 'Trade Shows & Events',
        description: 'On-time setup and breakdown deliveries for exhibitions and conventions.',
        image: 'trad.jpg',
        tintClass: 'bg-gray-900/75'
    },
    {
        title: 'White Glove Service',
        description: 'Premium handling for fragile, high-value, or specialized freight.',
        image: 'glove.jpg',
        tintClass: 'bg-blue-950/80'
    }
];
}),
"[project]/projects/apex landing/apex/src/app/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$section$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/section.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$FleetEqupment$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/FleetEqupment.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$About$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/About.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Contact$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/Contact.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Footer$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/Footer.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Header$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/Header.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Hero$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/Hero.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/projects/apex landing/apex/src/app/core/blocks/constants.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
function HeroSection() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: " bg-[#F5F5F5] flex flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Header$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 15,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "home",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Hero$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                    lineNumber: 17,
                    columnNumber: 7
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 16,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "services",
                className: "min-h-screen  py-16 sm:py-20 px-4 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-[1400px] mx-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center mb-12 space-y-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-3xl sm:text-4xl font-bold text-[#323e48] tracking-tight",
                                    children: "Transport Solutions That Work for You"
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                    lineNumber: 24,
                                    columnNumber: 11
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[1.05rem] sm:text-lg text-slate-500 font-light",
                                    children: "No matter the load — we deliver safely, on time, and with full visibility."
                                }, void 0, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                    lineNumber: 27,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                            lineNumber: 23,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SERVICES"].map((service, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$section$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ServiceCard"], {
                                    item: service
                                }, index, false, {
                                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                                    lineNumber: 36,
                                    columnNumber: 13
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                            lineNumber: 34,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                    lineNumber: 20,
                    columnNumber: 7
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 19,
                columnNumber: 2
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "fleet",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$FleetEqupment$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                    lineNumber: 43,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "about",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$About$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                    lineNumber: 46,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "contact",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Contact$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                    lineNumber: 49,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$projects$2f$apex__landing$2f$apex$2f$src$2f$app$2f$core$2f$blocks$2f$Footer$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/projects/apex landing/apex/src/app/page.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__d448c0cf._.js.map