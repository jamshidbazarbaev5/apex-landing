module.exports = [
"[project]/projects/apex landing/apex/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=projects_apex%20landing_apex__next-internal_server_app_page_actions_a518203b.js.map