var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/5f7a6_e4f6b07d._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/5f7a6_6cfc2702._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/5f7a6_next_02b873c7._.js")
R.m("[project]/projects/apex landing/apex/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/projects/apex landing/apex/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/projects/apex landing/apex/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/projects/apex landing/apex/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/projects/apex landing/apex/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/projects/apex landing/apex/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/projects/apex landing/apex/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/projects/apex landing/apex/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
