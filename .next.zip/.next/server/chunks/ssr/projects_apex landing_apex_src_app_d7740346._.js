module.exports=[52924,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},74410,a=>{"use strict";let b={src:a.i(52924).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=projects_apex%20landing_apex_src_app_d7740346._.js.map