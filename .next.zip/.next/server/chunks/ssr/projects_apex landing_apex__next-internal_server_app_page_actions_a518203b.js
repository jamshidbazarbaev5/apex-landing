module.exports=[67420,(a,b,c)=>{}];

//# sourceMappingURL=projects_apex%20landing_apex__next-internal_server_app_page_actions_a518203b.js.map