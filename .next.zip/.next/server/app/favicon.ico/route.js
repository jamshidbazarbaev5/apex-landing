var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__ce07fe5f._.js")
R.c("server/chunks/9e3a1_apex landing_apex__next-internal_server_app_favicon_ico_route_actions_373271e7.js")
R.m(6045)
module.exports=R.m(6045).exports
